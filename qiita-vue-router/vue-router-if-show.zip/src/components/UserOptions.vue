<template>
    <div class="root-div">
        設定画面（オプション変更画面）
    </div>
</template>


<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.root-div {
    margin: 8px;
}
</style>


<script>
export default {
    name : "UserOption",
    components: {
    },
    props: {
    },
    data : function () {
        return {
        }
    },
    mounted : function () {
        console.log('[UserOption][mounted]');
    },
    computed : {
    },
    created : function () {
        console.log('[UserOption][created]');
    },
    watch : {
    },
    methods : {
    }
}
</script>

