<template>
    <div class="root-div">
        ホームポータル画面<br>
        <br>
        ＜＜何らかの機能提供＞＞
    </div>
</template>


<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.root-div {
    margin: 32px;
}
</style>


<script>
export default {
    name : "HomePortal",
    components: {
    },
    props: {
    },
    data : function () {
        return {
        }
    },
    mounted : function () {
        console.log('[HomePortal][mounted]');
    },
    computed : {
    },
    created : function () {
        console.log('[HomePortal][created]');
    },
    watch : {
    },
    methods : {
    }
}
</script>

