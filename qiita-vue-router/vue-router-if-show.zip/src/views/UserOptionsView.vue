<template>
    <div>
        <UserOptions />
    </div>
</template>

<script>
// @ is an alias to /src
import UserOptions from '@/components/UserOptions.vue'

export default {
    name: 'UserOptionsView',
    components: {
        UserOptions
    }
}
</script>
